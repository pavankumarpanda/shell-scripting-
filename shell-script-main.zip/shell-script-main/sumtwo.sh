echo "Enter your two number"
read a
read b
echo "$(($a + $b))"


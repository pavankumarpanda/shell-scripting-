#!/bin/bash
echo "Enter filename to remove"
read fn
rm -i $fn
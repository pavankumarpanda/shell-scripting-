#!/bin/bash
function F1()
{
echo 'I like bash programming'
}

F1